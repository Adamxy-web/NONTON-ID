# NONTON ID — Android starter project

Aplikasi Android sederhana dengan UI bergaya layanan streaming, katalog kategori, pencarian, dan tautan ke sumber tayangan resmi.

## Fitur saat ini
- Tampilan gelap bergaya streaming.
- Kategori Drama, Komedi, Dokumenter, dan Film Pendek.
- Pencarian kategori.
- Tautan ke Vidio, Viddsee, dan YouTube.
- Pemutaran dilakukan di platform sumber; aplikasi ini tidak meng-host atau menyalin film.

## Cara membuat APK
1. Ekstrak ZIP ini.
2. Buka folder `NONTON_ID_Android` melalui Android Studio.
3. Tunggu Gradle Sync selesai (Android Studio JDK 17 direkomendasikan).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Project ini adalah source project Android, bukan APK yang sudah dikompilasi.
- Katalog gratis dan ketersediaan judul berubah mengikuti lisensi tiap penyedia.
- Periksa label Gratis pada layanan tujuan. Sebagian konten memerlukan akun atau paket berbayar.
- Untuk distribusi publik, tambahkan kebijakan privasi, ikon aplikasi, pengujian perangkat, dan konfigurasi signing release.
